import { cn } from "@/lib/utils";

/**
 * Skeleton simples para loading (listas/cards).
 */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-md bg-muted/70", className)} />;
}
