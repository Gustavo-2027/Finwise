"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowUpRight, Sparkles } from "lucide-react";

import { cn } from "@/lib/utils";
import type { TransactionRow } from "@/modules/transactions/types";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { createRuleFromTransactionAction } from "@/modules/rules/actions/create-rule-from-transaction";



function formatMoneyFromCents(cents: number, type: TransactionRow["type"]) {
  const value = Math.abs(cents) / 100;

  const formatted = value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });

  return type === "expense" ? `- ${formatted}` : formatted;
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
}

function TypePill({ type }: { type: TransactionRow["type"] }) {
  const isIncome = type === "income";

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
        isIncome
          ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
          : "bg-rose-500/10 text-rose-600 dark:text-rose-400"
      )}
    >
      {isIncome ? "Entrada" : "Saída"}
    </span>
  );
}

function InboxPill() {
  return (
    <span className="inline-flex items-center rounded-full border bg-background/60 px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
      Inbox
    </span>
  );
}

function isInbox(categoryName: string) {
  return categoryName.trim().toLowerCase() === "inbox";
}

function RuleDialog({
  open,
  onOpenChange,
  transaction,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transaction: { id: string; title: string };
}) {
  const [ruleName, setRuleName] = useState("");

  // sugestão automática de nome (não precisa useEffect)
  const suggested = useMemo(() => {
    const base = transaction.title.trim();
    if (!base) return "Nova regra";
    return base.length > 32 ? `${base.slice(0, 32)}…` : base;
  }, [transaction.title]);

  const defaultRuleName = ruleName || suggested;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base">Criar regra</DialogTitle>
        </DialogHeader>

        <form
          action={async (fd) => {
            // mantém “sugestão” se usuário não digitou nada
            if (!fd.get("name")) fd.set("name", defaultRuleName);
            await createRuleFromTransactionAction(fd);
            onOpenChange(false);
          }}
          className="space-y-4"
        >
          <input type="hidden" name="transactionId" value={transaction.id} />
          <input type="hidden" name="contains" value={transaction.title} />

          <div className="space-y-2">
            <Label htmlFor="name">Nome da regra</Label>
            <Input
              id="name"
              name="name"
              value={ruleName}
              onChange={(e) => setRuleName(e.target.value)}
              placeholder={suggested}
            />
            <p className="text-xs text-muted-foreground">
              A regra vai aplicar automaticamente quando o título contiver o texto acima.
            </p>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>

            <Button type="submit" className="gap-2">
              <Sparkles className="h-4 w-4" />
              Criar regra
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function TransactionsTable({ rows }: { rows: TransactionRow[] }) {
  const [ruleTx, setRuleTx] = useState<{ id: string; title: string } | null>(null);

  return (
    <>
      <TooltipProvider delayDuration={120}>
        <div className="hidden md:block">
          <div className="overflow-hidden rounded-xl border bg-card">
            <div className="grid grid-cols-12 border-b bg-muted/30 px-4 py-2 text-xs text-muted-foreground">
              <div className="col-span-4">Descrição</div>
              <div className="col-span-2">Categoria</div>
              <div className="col-span-2">Conta</div>
              <div className="col-span-2">Tipo</div>
              <div className="col-span-2 text-right">Valor</div>
            </div>

            <div className="divide-y">
              {rows.map((t) => {
                const href = `/transactions/${t.id}/edit`;
                const income = t.type === "income";
                const inbox = isInbox(t.categoryName);

                return (
                  <div key={t.id} className="relative">
                    <Link
                      href={href}
                      aria-label={`Editar transação: ${t.title}`}
                      className={cn(
                        "block focus:outline-none",
                        "focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      )}
                    >
                      <div className="grid grid-cols-12 px-4 py-3 text-sm transition-colors hover:bg-muted/20">
                        <div className="col-span-4 min-w-0">
                          <div className="truncate font-medium leading-none">{t.title}</div>
                          <div className="mt-1 text-xs text-muted-foreground">
                            {formatDate(t.occurredAt)}
                          </div>
                        </div>

                        <div className="col-span-2 min-w-0">
                          {inbox ? (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="inline-flex">
                                  <InboxPill />
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                Sem categoria. Você pode criar uma regra para categorizar automaticamente.
                              </TooltipContent>
                            </Tooltip>
                          ) : (
                            <div className="truncate text-muted-foreground">{t.categoryName}</div>
                          )}
                        </div>

                        <div className="col-span-2 truncate text-muted-foreground">
                          {t.accountName}
                        </div>

                        <div className="col-span-2">
                          <TypePill type={t.type} />
                        </div>

                        <div
                          className={cn(
                            "col-span-2 text-right font-medium tabular-nums",
                            income ? "text-emerald-600 dark:text-emerald-400" : "text-foreground"
                          )}
                        >
                          {formatMoneyFromCents(t.amountCents, t.type)}
                        </div>
                      </div>
                    </Link>

                    {inbox ? (
                      <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">
                        <div className="pointer-events-auto">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-8 gap-2"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setRuleTx({ id: t.id, title: t.title });
                            }}
                          >
                            <Sparkles className="h-4 w-4" />
                            Criar regra
                            <ArrowUpRight className="h-4 w-4 opacity-70" />
                          </Button>
                        </div>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>

          <p className="mt-2 text-xs text-muted-foreground">
            Dica: clique em uma transação para editar. Quando estiver em Inbox, você pode criar uma regra.
          </p>
        </div>

        <div className="grid gap-2 md:hidden">
          {rows.map((t) => {
            const href = `/transactions/${t.id}/edit`;
            const income = t.type === "income";
            const inbox = isInbox(t.categoryName);

            return (
              <div key={t.id} className="space-y-2">
                <Link
                  href={href}
                  aria-label={`Editar transação: ${t.title}`}
                  className={cn(
                    "block rounded-xl border bg-background/40 p-3 transition-colors",
                    "hover:bg-muted/10 focus:outline-none",
                    "focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{t.title}</div>

                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span>{formatDate(t.occurredAt)}</span>
                        <span>•</span>

                        {inbox ? <InboxPill /> : <span className="truncate">{t.categoryName}</span>}

                        <span>•</span>
                        <span className="truncate">{t.accountName}</span>
                      </div>

                      <div className="mt-2">
                        <TypePill type={t.type} />
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      <div
                        className={cn(
                          "text-sm font-semibold tabular-nums",
                          income ? "text-emerald-600 dark:text-emerald-400" : "text-foreground"
                        )}
                      >
                        {formatMoneyFromCents(t.amountCents, t.type)}
                      </div>
                    </div>
                  </div>
                </Link>

                {inbox ? (
                  <div className="flex justify-end">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => setRuleTx({ id: t.id, title: t.title })}
                    >
                      <Sparkles className="h-4 w-4" />
                      Criar regra
                    </Button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </TooltipProvider>

      {ruleTx ? (
        <RuleDialog open={!!ruleTx} onOpenChange={(v) => (!v ? setRuleTx(null) : null)} transaction={ruleTx} />
      ) : null}
    </>
  );
}
