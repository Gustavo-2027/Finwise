import { z } from "zod";

function normalizeText(v: unknown) {
  return String(v ?? "").trim();
}

function parseBrlToNumber(v: unknown) {
  const raw = normalizeText(v);
  if (!raw) return NaN;

  const normalized = raw.replace(/\./g, "").replace(",", ".");
  const n = Number(normalized);
  return Number.isFinite(n) ? n : NaN;
}

function normalizeCategoryId(v: unknown) {
  const raw = normalizeText(v);

  if (!raw) return null;
  if (raw === "none") return null;
  if (raw === "__inbox__") return null;

  return raw;
}

export const createTransactionSchema = z.object({
  title: z.string().trim().min(2, "Informe uma descrição."),

  amount: z.preprocess(parseBrlToNumber, z.number().positive("Informe um valor válido.")),

  type: z.enum(["income", "expense"]),

  accountId: z.string().uuid("Conta inválida."),

  categoryId: z.preprocess(
    normalizeCategoryId,
    z.string().uuid("Categoria inválida.").nullable()
  ),

  date: z.string().min(10, "Data inválida."),

  note: z.string().trim().max(500, "Observação muito longa (máx. 500 caracteres).").optional(),
});

export const updateTransactionSchema = createTransactionSchema.extend({
  id: z.string().uuid("ID inválido."),
});

export type CreateTransactionInput = z.infer<typeof createTransactionSchema>;
export type UpdateTransactionInput = z.infer<typeof updateTransactionSchema>;
