import type { TransactionType } from "./domain/transaction.types";

export type TransactionRow = {
  id: string;
  title: string;

  type: TransactionType;

  occurredAt: string;
  amountCents: number;

  accountName: string;
  categoryName: string;
};

export type TxTypeFilter = "all" | TransactionType;
export type MonthFilter = "this-month" | "last-month" | string; // YYYY-MM

export type TransactionsFilters = {
  q?: string;
  month?: MonthFilter;
  type?: TxTypeFilter;
  page?: number;
  pageSize?: number;
};

export type TransactionsResult = {
  rows: TransactionRow[];
  total: number;
  totalPages: number;
  page: number;
  pageSize: number;
};
