import { supabaseServer } from "@/infrastructure/supabase/server";
import type { TransactionRow } from "@/modules/transactions/types";

type TxTypeFilter = "all" | "income" | "expense";
type MonthFilter = "this-month" | "last-month" | string; // YYYY-MM

export type GetTransactionsInput = {
  q?: string;
  month?: MonthFilter;
  type?: TxTypeFilter;
  page?: number;
  pageSize?: number;
};

export type GetTransactionsResponse =
  | {
      ok: true;
      rangeLabel: string;
      result: {
        rows: TransactionRow[];
        total: number;
        totalPages: number;
      };
    }
  | {
      ok: false;
      message: string;
    };

type DbTransactionRow = {
  id: string;
  title: string;
  type: "income" | "expense";
  occurred_at: string;
  amount_cents: number | string;

  account_id: string;
  category_id: string | null;

  account: { name: string } | null;
  category: { name: string } | null;
};

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function toInt(n: unknown) {
  const v = typeof n === "number" ? n : Number(n);
  return Number.isFinite(v) ? Math.trunc(v) : 0;
}

function getUtcMonthRangeFromYYYYMM(yyyymm: string) {
  const [y, m] = yyyymm.split("-").map(Number);
  const start = new Date(Date.UTC(y, m - 1, 1, 0, 0, 0));
  const end = new Date(Date.UTC(y, m, 1, 0, 0, 0));
  return { startISO: start.toISOString(), endISO: end.toISOString() };
}

function getThisMonthUtcRange() {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = now.getUTCMonth();
  return {
    startISO: new Date(Date.UTC(y, m, 1)).toISOString(),
    endISO: new Date(Date.UTC(y, m + 1, 1)).toISOString(),
  };
}

function getLastMonthUtcRange() {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = now.getUTCMonth();
  return {
    startISO: new Date(Date.UTC(y, m - 1, 1)).toISOString(),
    endISO: new Date(Date.UTC(y, m, 1)).toISOString(),
  };
}

function formatRangeLabel(month: MonthFilter | undefined) {
  if (!month || month === "this-month") return "Este mês";
  if (month === "last-month") return "Último mês";
  return month;
}

export async function getTransactions(
  input: GetTransactionsInput,
): Promise<GetTransactionsResponse> {
  const supabase = await supabaseServer();

  const { data: authData, error: authError } = await supabase.auth.getUser();
  const user = authData?.user;

  if (authError || !user) {
    return { ok: false, message: "Sessão inválida. Faça login novamente." };
  }

  const q = (input.q ?? "").trim();
  const type = input.type ?? "all";
  const month = input.month ?? "this-month";

  const pageSize = clamp(input.pageSize ?? 10, 5, 50);
  const page = clamp(input.page ?? 1, 1, 999);
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  const range =
    month === "this-month"
      ? getThisMonthUtcRange()
      : month === "last-month"
        ? getLastMonthUtcRange()
        : getUtcMonthRangeFromYYYYMM(month);

  let query = supabase
    .from("transactions")
    .select(
      `
    id,
    title,
    type,
    occurred_at,
    amount_cents,
    account_id,
    category_id,
    account:accounts!transactions_account_id_user_id_fkey ( name ),
    category:categories!transactions_category_id_user_id_fkey ( name )
  `,
      { count: "exact" },
    )

    .eq("user_id", user.id)
    .gte("occurred_at", range.startISO)
    .lt("occurred_at", range.endISO);

  if (type !== "all") query = query.eq("type", type);
  if (q) query = query.ilike("title", `%${q}%`);

  const { data, error, count } = await query
    .order("occurred_at", { ascending: false })
    .range(from, to)
    .returns<DbTransactionRow[]>();

  if (error) return { ok: false, message: error.message };

  const rows: TransactionRow[] = (data ?? []).map((r) => {
    const categoryId = r.category_id ?? null;

    return {
      id: r.id,
      title: r.title,
      type: r.type,
      occurredAt: r.occurred_at,
      amountCents: toInt(r.amount_cents),
      accountName: r.account?.name ?? "—",
      categoryName: categoryId ? (r.category?.name ?? "—") : "Inbox",
    };
  });

  const total = count ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return {
    ok: true,
    rangeLabel: formatRangeLabel(month),
    result: { rows, total, totalPages },
  };
}
