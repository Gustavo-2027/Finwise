"use server";

import { redirect } from "next/navigation";
import { z } from "zod";

import { supabaseServer } from "@/infrastructure/supabase/server";
import { setFlashToast } from "@/shared/flash/flash-toast";

function normalizeText(v: unknown) {
  return String(v ?? "").trim();
}

function parseBrlToNumber(v: unknown) {
  const raw = normalizeText(v);
  if (!raw) return NaN;

  const normalized = raw.replace(/\./g, "").replace(",", ".");
  const n = Number(normalized);
  return Number.isFinite(n) ? n : NaN;
}

/**
 * "" | "none" | "__inbox__" -> null
 * uuid -> uuid
 */
function normalizeCategoryId(v: unknown) {
  const raw = normalizeText(v);
  if (!raw) return null;
  if (raw === "none") return null;
  if (raw === "__inbox__") return null;
  return raw;
}

const moneyNumber = z.preprocess(
  parseBrlToNumber,
  z.number().finite("Informe um valor válido.").positive("Informe um valor válido.")
);

const updateSchema = z.object({
  id: z.string().uuid(),
  title: z.string().trim().min(2, "Informe uma descrição."),
  amount: moneyNumber,
  type: z.enum(["income", "expense"]),
  accountId: z.string().uuid("Conta inválida."),

  // ✅ Agora aceita Inbox
  categoryId: z.preprocess(
    normalizeCategoryId,
    z.string().uuid("Categoria inválida.").nullable()
  ),

  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida."),
  note: z.string().trim().max(500, "Observação muito longa (máx. 500 caracteres).").optional(),
});

function parseFormData(formData: FormData) {
  return {
    id: String(formData.get("id") ?? ""),
    title: String(formData.get("title") ?? ""),
    amount: String(formData.get("amount") ?? ""),
    type: String(formData.get("type") ?? "expense"),
    accountId: String(formData.get("accountId") ?? ""),
    categoryId: String(formData.get("categoryId") ?? ""), // "" = inbox
    date: String(formData.get("date") ?? ""),
    note: String(formData.get("note") ?? ""),
  };
}

function toCents(amount: number) {
  return Math.round(amount * 100);
}

function dateToIso(date: string) {
  return new Date(`${date}T12:00:00.000Z`).toISOString();
}

export async function updateTransactionAction(formData: FormData) {
  const raw = parseFormData(formData);
  const parsed = updateSchema.safeParse(raw);

  if (!parsed.success) {
    await setFlashToast({
      type: "error",
      title: "Não foi possível salvar",
      description: parsed.error.issues[0]?.message ?? "Verifique os campos.",
    });
    redirect(`/transactions/${raw.id}/edit`);
  }

  const supabase = await supabaseServer();
  const { data: auth, error: authError } = await supabase.auth.getUser();
  const user = auth?.user;

  if (authError || !user) {
    await setFlashToast({
      type: "error",
      title: "Sessão inválida",
      description: "Faça login novamente.",
    });
    redirect("/login");
  }

  const input = parsed.data;

  const occurredAt = dateToIso(input.date);
  const amountCents = toCents(input.amount);
  const note = input.note?.trim() ? input.note.trim() : null;

  const { error } = await supabase
    .from("transactions")
    .update({
      title: input.title,
      type: input.type,
      account_id: input.accountId,
      category_id: input.categoryId, // ✅ pode ser null (Inbox)
      occurred_at: occurredAt,
      amount_cents: amountCents,
      note,
    })
    .eq("id", input.id)
    .eq("user_id", user.id);

  if (error) {
    await setFlashToast({
      type: "error",
      title: "Erro ao salvar",
      description: error.message,
    });
    redirect(`/transactions/${input.id}/edit`);
  }

  await setFlashToast({ type: "success", title: "Transação atualizada" });
  redirect("/transactions");
}
