"use server";

import { redirect } from "next/navigation";

import type { Database } from "@/shared/types/database.types";
import { supabaseServer } from "@/infrastructure/supabase/server";
import { setFlashToast } from "@/shared/flash/flash-toast";

import { getEnabledRulesForCurrentUser } from "@/modules/rules/api/get-enabled-rules";
import { applyRulesToTransaction } from "@/modules/rules/domain/apply-rules-to-transaction";
import { createTransactionSchema } from "../schemas/transaction-form.schema";


type TransactionInsert = Database["public"]["Tables"]["transactions"]["Insert"];

function parseFormData(formData: FormData) {
  return {
    title: String(formData.get("title") ?? ""),
    amount: String(formData.get("amount") ?? ""),
    type: String(formData.get("type") ?? "expense"),
    accountId: String(formData.get("accountId") ?? ""),
    categoryId: String(formData.get("categoryId") ?? ""), // "" = Inbox
    date: String(formData.get("date") ?? ""), // YYYY-MM-DD
    note: String(formData.get("note") ?? ""),
  };
}

function toCents(amount: number) {
  return Math.round(amount * 100);
}

/**
 * yyyy-mm-dd -> UTC 12:00
 * Evita bug de “voltar um dia” em timezones negativos (ex: -03).
 */
function dateToIso(date: string) {
  return new Date(`${date}T12:00:00.000Z`).toISOString();
}

export async function createTransactionAction(formData: FormData) {
  const raw = parseFormData(formData);
  const parsed = createTransactionSchema.safeParse(raw);

  if (!parsed.success) {
    await setFlashToast({
      type: "error",
      title: "Não foi possível criar",
      description: parsed.error.issues[0]?.message ?? "Verifique os campos.",
    });
    redirect("/transactions/new");
  }

  const supabase = await supabaseServer();
  const { data: auth, error: authError } = await supabase.auth.getUser();
  const user = auth?.user;

  if (authError || !user) {
    await setFlashToast({
      type: "error",
      title: "Sessão inválida",
      description: "Faça login novamente.",
    });
    redirect("/login");
  }

  const input = parsed.data;

  const occurredAt = dateToIso(input.date);
  const amountCents = toCents(input.amount);
  const note = input.note?.trim() ? input.note.trim() : null;

  // account_id é NOT NULL no banco
  const accountId = input.accountId;

  // No schema, Inbox vira null (se você configurou isso nele)
  let finalCategoryId: string | null = input.categoryId;

  // Aplica rules só se não veio categoria manual
  if (!finalCategoryId) {
    try {
      const rules = await getEnabledRulesForCurrentUser();

      const ruleResult = applyRulesToTransaction(
        {
          description: input.title,
          type: input.type,
          accountId,
          categoryId: null,
        },
        rules
      );

      finalCategoryId = ruleResult.categoryId ?? null;
    } catch {
      finalCategoryId = null;
    }
  }

  const payload: TransactionInsert = {
    user_id: user.id,
    title: input.title,
    type: input.type,

    account_id: accountId,
    category_id: finalCategoryId,

    occurred_at: occurredAt,
    amount_cents: amountCents,

    note,
  };

  const { error } = await supabase.from("transactions").insert(payload);

  if (error) {
    await setFlashToast({
      type: "error",
      title: "Erro ao salvar transação",
      description: error.message,
    });
    redirect("/transactions/new");
  }

  await setFlashToast({
    type: "success",
    title: "Transação criada",
    description: "Sua transação foi adicionada com sucesso.",
  });

  redirect("/transactions");
}
