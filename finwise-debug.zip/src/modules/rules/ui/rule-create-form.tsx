"use client";

import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Option = { id: string; name: string };

export function RuleCreateForm(props: {
  accounts: Option[];
  categories: Option[];
  action: (formData: FormData) => void;
}) {
  const { accounts, categories, action } = props;

  const [matchType, setMatchType] = useState<"contains" | "starts_with" | "regex">(
    "contains"
  );
  const [applyType, setApplyType] = useState<"all" | "income" | "expense">("all");
  const [accountId, setAccountId] = useState<string>("__all__");
  const [categoryId, setCategoryId] = useState<string>("__none__");

  return (
    <form action={action} className="space-y-4">
      {/* Hidden inputs que REALMENTE vão para o FormData */}
      <input type="hidden" name="isEnabled" value="true" />
      <input type="hidden" name="matchType" value={matchType} />
      <input type="hidden" name="applyType" value={applyType} />
      <input type="hidden" name="accountId" value={accountId} />
      <input type="hidden" name="categoryId" value={categoryId} />

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="pattern">Padrão</Label>
          <Input
            id="pattern"
            name="pattern"
            placeholder='Ex: "UBER", "IFOOD", "AMAZON"'
            required
          />
          <div className="text-xs text-muted-foreground">
            Dica: use termos que aparecem no título. Para Regex, informe só o padrão (sem / /).
            Ex: <span className="font-mono">^UBER</span>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Match</Label>
          <Select value={matchType} onValueChange={(v) => setMatchType(v as any)}>
            <SelectTrigger>
              <SelectValue placeholder="Tipo de match" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contains">Contém</SelectItem>
              <SelectItem value="starts_with">Começa com</SelectItem>
              <SelectItem value="regex">Regex</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Aplicar em</Label>
          <Select value={applyType} onValueChange={(v) => setApplyType(v as any)}>
            <SelectTrigger>
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="income">Entradas</SelectItem>
              <SelectItem value="expense">Saídas</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Prioridade</Label>
          <Input id="priority" name="priority" type="number" min={0} defaultValue={100} />
          <div className="text-xs text-muted-foreground">
            Menor = aplica primeiro (desempate por data de criação).
          </div>
        </div>

        <div className="space-y-2">
          <Label>Conta (opcional)</Label>
          <Select value={accountId} onValueChange={setAccountId}>
            <SelectTrigger>
              <SelectValue placeholder="Todas as contas" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Todas as contas</SelectItem>
              {accounts.map((a) => (
                <SelectItem key={a.id} value={a.id}>
                  {a.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Categoria (opcional)</Label>
          <Select value={categoryId} onValueChange={setCategoryId}>
            <SelectTrigger>
              <SelectValue placeholder="Sem categoria (Inbox)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">Sem categoria (Inbox)</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Button type="submit">Criar regra</Button>
    </form>
  );
}
