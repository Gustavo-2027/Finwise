"use server";

import { redirect } from "next/navigation";

import type { Database } from "@/shared/types/database.types";
import { supabaseServer } from "@/infrastructure/supabase/server";
import { setFlashToast } from "@/shared/flash/flash-toast";

type RulesInsert = Database["public"]["Tables"]["rules"]["Insert"];
type RuleApplyType = Database["public"]["Enums"]["rule_apply_type"];

function parse(formData: FormData) {
  return {
    pattern: String(formData.get("pattern") ?? "").trim(),
    applyType: String(formData.get("applyType") ?? "all").trim(),
    accountId: String(formData.get("accountId") ?? "").trim(),
    categoryId: String(formData.get("categoryId") ?? "").trim(),
    priority: String(formData.get("priority") ?? "100").trim(),
  };
}

function emptyOrNoneToNull(v: string) {
  const s = v.trim();
  if (!s || s === "none") return null;
  return s;
}

function clampInt(value: string, fallback: number, min: number, max: number) {
  const n = Number.parseInt(value, 10);
  if (Number.isNaN(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function toApplyType(value: string): RuleApplyType {
  if (value === "income" || value === "expense" || value === "all") return value;
  return "all";
}

export async function createRuleFromTransactionAction(formData: FormData) {
  const input = parse(formData);

  if (input.pattern.length < 2) {
    await setFlashToast({
      type: "error",
      title: "Não foi possível criar regra",
      description: "O padrão precisa ter pelo menos 2 caracteres.",
    });
    redirect("/transactions");
  }

  const supabase = await supabaseServer();
  const { data: auth, error: authError } = await supabase.auth.getUser();
  const user = auth?.user;

  if (authError || !user) {
    await setFlashToast({
      type: "error",
      title: "Sessão inválida",
      description: "Faça login novamente.",
    });
    redirect("/login");
  }

  const payload: RulesInsert = {
    user_id: user.id,
    is_enabled: true,
    priority: clampInt(input.priority, 100, 0, 1000),

    match_type: "contains",
    pattern: input.pattern,

    apply_type: toApplyType(input.applyType),

    account_id: emptyOrNoneToNull(input.accountId),
    category_id: emptyOrNoneToNull(input.categoryId),
  };

  const { error } = await supabase.from("rules").insert(payload);

  if (error) {
    await setFlashToast({
      type: "error",
      title: "Erro ao criar regra",
      description: error.message,
    });
    redirect("/transactions");
  }

  await setFlashToast({
    type: "success",
    title: "Regra criada",
    description: "Novas transações compatíveis serão categorizadas automaticamente.",
  });

  redirect("/transactions");
}
