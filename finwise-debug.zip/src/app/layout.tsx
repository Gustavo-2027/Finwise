import "./globals.css";

import type { Metadata } from "next";
import { Toaster } from "sonner";

import { ThemeProvider } from "@/shared/providers/theme-provider";

export const metadata: Metadata = {
  title: {
    default: "Finwise",
    template: "%s • Finwise",
  },
  description: "Finwise — controle financeiro pessoal com automação inteligente.",
  applicationName: "Finwise",
  icons: [{ rel: "icon", url: "/favicon.ico" }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className="min-h-dvh bg-background text-foreground antialiased">
        <ThemeProvider>
          {children}
        </ThemeProvider>

        <Toaster richColors position="top-right" duration={3500} />
      </body>
    </html>
  );
}
